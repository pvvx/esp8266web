/******************************************************************************
 * PV` FileName: tcp_client.c
*******************************************************************************/
#include "user_config.h"
#include "bios.h"
#include "sdk/add_func.h"
#include "c_types.h"
#include "osapi.h"
#include "lwip/tcp.h"
#include "lwip/dns.h"
#include "tcp_srv_conn.h"
#include "web_utils.h"
#include "ovl_sys.h"

#define DEFAULT_TC_HOST_PORT 80

#define tc_error		mdb_buf.ubuf[50]
#define tc_init_usr		mdb_buf.ubuf[51]
#define tc_temp1		mdb_buf.ubuf[52]
#define tc_temp2		mdb_buf.ubuf[53]
//#define	tc_url    		((uint8 *)(mdb_buf.ubuf+20))

uint8 tc_url[] = "weather-in.ru";
uint8 tc_get[] = "GET /sankt-peterbyrg/107709 HTTP/1.0/\r\nHost: weather-in.ru\r\n\r\n";
uint8 key_http_ok[] = "HTTP/1.1 200 OK\r\n";
//uint8 key_chunked[] = "Transfer-Encoding: chunked";

uint8 key_td_info[] = "<td class=\"info\">";

//uint32 content_chunked DATA_IRAM_ATTR;
//os_timer_t test_timer DATA_IRAM_ATTR;

ip_addr_t tc_remote_ip;
int tc_init_flg DATA_IRAM_ATTR;
uint32 tc_head_size DATA_IRAM_ATTR;

#define mMIN(a, b)  ((a<b)?a:b)

TCP_SERV_CFG * tc_servcfg DATA_IRAM_ATTR;
//-------------------------------------------------------------------------------
// tc_close
//-------------------------------------------------------------------------------
void ICACHE_FLASH_ATTR tc_close(void)
{
//	tc_port = 0;
	if(tc_servcfg != NULL) {
		tcpsrv_close(tc_servcfg);
		tc_servcfg = NULL;
#if DEBUGSOO > 1
		os_printf("TC: close\n");
#endif
	}
	tc_init_flg = 0;
}
//-------------------------------------------------------------------------------
// TCP sent_cb
//-------------------------------------------------------------------------------
/*
err_t ICACHE_FLASH_ATTR tc_sent_cb(TCP_SERV_CONN *ts_conn) {
#if DEBUGSOO > 1
	tcpsrv_sent_callback_default(ts_conn);
#endif
	tc_sconn = ts_conn;
	return ERR_OK;
}
*/
//-------------------------------------------------------------------------------
// TCP recv
//-------------------------------------------------------------------------------
err_t ICACHE_FLASH_ATTR tc_recv(TCP_SERV_CONN *ts_conn) {
#if DEBUGSOO > 1
	tcpsrv_received_data_default(ts_conn);
#endif
	tcpsrv_unrecved_win(ts_conn);
    uint8 *pstr = ts_conn->pbufi;
    sint32 len = ts_conn->sizei;
    if(tc_head_size == 0) {
        if(len < sizeof(key_http_ok) +2 -1) {
        	return ERR_OK;
        }
        if(os_memcmp(key_http_ok, pstr, sizeof(key_http_ok)-1)==0) {
        	tc_head_size = sizeof(key_http_ok)-1;
        	len -= sizeof(key_http_ok)-1;
        	pstr += sizeof(key_http_ok)-1;
        }
        else {
        	tc_error = -25;
        	tc_close();
        	return ERR_OK;
        }
        uint8 * nstr = web_strnstr(pstr, "\r\n\r\n", len);
        if(nstr == NULL) return ERR_OK;
        *nstr = '\0';
        tc_head_size = nstr - ts_conn->pbufi + 4;
        ts_conn->cntri = tc_head_size;
#if DEBUGSOO > 4
    	os_printf("head[%d]: '%s' ", tc_head_size, ts_conn->pbufi);
#endif
/*        if(web_strnstr(pstr, key_chunked, len) != NULL) {
        	content_chunked = 1;
        }
        else content_chunked = 0; */
        pstr = &ts_conn->pbufi[ts_conn->cntri];
        len = ts_conn->sizei - ts_conn->cntri;
#if DEBUGSOO > 3
    	os_printf("str: '%s' ", ts_conn->pbufi);
#endif
    }
    if(tc_head_size != 0 && len > sizeof(key_td_info) + 1) {
#if DEBUGSOO > 5
    	os_printf("content[%d] ", len);
#endif
    	uint8 * nstr = web_strnstr(pstr, key_td_info, len);
    	if(nstr == NULL) {
    		ts_conn->cntri = ts_conn->sizei - sizeof(key_td_info) + 1;
        	return ERR_OK;
    	}
    	else {
    		pstr = nstr + sizeof(key_td_info) - 1;
    		len = &ts_conn->pbufi[ts_conn->sizei] - pstr;
    		if(len > 20) nstr = web_strnstr(pstr, "</td>", len);
    		else return ERR_OK;
    		if(nstr != NULL && nstr[-1] == 'C') {
        		*nstr++ ='\0';
#if DEBUGSOO > 1
        		os_printf("\"%s\" ", pstr);
#endif
        		pstr = nstr + 5;
        		len = &ts_conn->pbufi[ts_conn->sizei] - pstr;
           		if(len > 20) nstr = web_strnstr(pstr, "</td>", len);
           		else return ERR_OK;
           		if(nstr != NULL) {
               		*nstr ='\0';
               		while(pstr < nstr && *pstr++ != '>');
      				tc_temp1 = rom_atoi(pstr);
               		while(pstr < nstr && *pstr++ != '>');
      				tc_temp2 = rom_atoi(pstr);
#if DEBUGSOO > 1
               		os_printf("%d..%d ", (sint16)tc_temp1, (sint16)tc_temp2);
#endif
               		nstr++;
               		ts_conn->flag.rx_null = 1;
           		}
    		}
   			ts_conn->cntri = nstr - ts_conn->pbufi;
   			tc_error = 0;
    	}
    }
	return ERR_OK;
}
//-------------------------------------------------------------------------------
// TCP listen
//-------------------------------------------------------------------------------
err_t ICACHE_FLASH_ATTR tc_listen(TCP_SERV_CONN *ts_conn) {
#if DEBUGSOO > 1
	tcpsrv_print_remote_info(ts_conn);
	os_printf("send %d bytes\n", sizeof(tc_get)-1);
#endif
	return tcpsrv_int_sent_data(ts_conn, tc_get, sizeof(tc_get)-1);
}
//-------------------------------------------------------------------------------
// TCP disconnect
//-------------------------------------------------------------------------------
void ICACHE_FLASH_ATTR tc_disconnect(TCP_SERV_CONN *ts_conn) {
#if DEBUGSOO > 1
	tcpsrv_disconnect_calback_default(ts_conn);
#endif
}
//-------------------------------------------------------------------------------
// tc_start
//-------------------------------------------------------------------------------
err_t ICACHE_FLASH_ATTR tc_init(void)
{
	err_t err = ERR_USE;
	tc_close();
	TCP_SERV_CFG * p = tcpsrv_init_client3();  // tcpsrv_init(3)
	if (p != NULL) {
		// изменим конфиг на наше усмотрение:
		p->max_conn = 3; // =0 - вечная попытка соединения
		p->flag.rx_buf = 1; // прием в буфер с его автосозданием.
		p->flag.nagle_disabled = 1; // отмена nagle
//		p->time_wait_rec = tc_twrec; // =0 -> вечное ожидание
//		p->time_wait_cls = tc_twcls; // =0 -> вечное ожидание
#if DEBUGSOO > 5
		os_printf("TC: Max retry connection %d, time waits %d & %d, min heap size %d\n",
					p->max_conn, p->time_wait_rec, p->time_wait_cls, p->min_heap);
#endif
		p->func_discon_cb = tc_disconnect;
		p->func_listen = tc_listen;
		p->func_sent_cb = NULL;
		p->func_recv = tc_recv;
		tc_init_flg = 1;
		err = ERR_OK;
	}
//	else err = ERR_USE;
	tc_servcfg = p;
	return err;
}

//-------------------------------------------------------------------------------
// tc_start
//-------------------------------------------------------------------------------
void tc_dns_found_callback(uint8 *name, ip_addr_t *ipaddr, void *callback_arg)
{
#if DEBUGSOO > 5
	os_printf("clb:%s, " IPSTR " ", name, IP2STR(ipaddr));
#endif
	if(tc_servcfg != NULL) {
		if(ipaddr != NULL && ipaddr->addr != 0) {
			tc_remote_ip = *ipaddr;
			tc_head_size = 0;
			tc_error = tcpsrv_client_start(tc_servcfg, tc_remote_ip.addr, DEFAULT_TC_HOST_PORT);
			if (tc_error == ERR_OK) tc_init_flg = 1;
			else {
#if DEBUGSOO > 5
				os_printf("goerr=%d ", tc_error);
#endif
				tc_close();
			}
		}
	}
}

err_t tc_go(void)
{
	err_t err = dns_gethostbyname(tc_url, &tc_remote_ip, (dns_found_callback)tc_dns_found_callback, NULL);
#if DEBUGSOO > 5
	os_printf("dns_gethostbyname(%s)=%d ", tc_url, err);
#endif

	if(err == ERR_OK) {	// Адрес разрешен из кэша или локальной таблицы
		tc_head_size = 0;
		err = tcpsrv_client_start(tc_servcfg, tc_remote_ip.addr, DEFAULT_TC_HOST_PORT);
	}
	else if(err == ERR_INPROGRESS) { // Запущен процесс разрешения имени с внешнего DNS
		tc_init_flg = 2;
		err = ERR_OK;
	}
	if (err != ERR_OK) {
		tc_close();
	}
	tc_error = err;
#if DEBUGSOO > 5
	os_printf("goerr=%d ", tc_error);
#endif
	return err;
}
//=============================================================================
//=============================================================================
int ovl_init(int flg)
{
	int ret = 0;
	if(flg == 1) {
		err_t err = tc_init();
		if(err != ERR_OK || tc_go() != ERR_OK) {
#if DEBUGSOO > 1
				os_printf("err=%d,%d ", tc_error, err);
#endif
				ret = -1;
		}
		else tc_init_usr = 1;
	}
	else {
		if(tc_init_flg&2) {
			ret = -2;
		}
		tc_close();
		tc_init_usr = 0;
	}
	return ret;
}

