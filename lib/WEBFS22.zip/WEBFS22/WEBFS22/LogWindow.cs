﻿/*********************************************************************
 *
 *    Log Window dialog
 *
 ********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FWEB2
{
    public partial class LogWindow : Form
    {
        public Icon Image
        {
            set
            {
                iconBox.Image = Icon.FromHandle(value.Handle).ToBitmap();
            }
        }

        public List<string> Log
        {
            set
            {
                foreach (String s in value)
                {
                    txtLogWindow.Text += s + "\r\n";
                }
            }
        }

        public String Message
        {
            set { txtMessage.Text = value; }
        }

        public LogWindow()
        {
            InitializeComponent();
        }

        private void LogWindow_Load(object sender, EventArgs e)
        {
            txtLogWindow.Select(0, 0);
            btnOK.Select();
        }
    }
}
