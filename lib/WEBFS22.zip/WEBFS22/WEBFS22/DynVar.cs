﻿/*********************************************************************
 *
 *    Dynamic Variable Parser Library
 *
 ********************************************************************/
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace WEBFS
{
    public class DynamicVariableParser
    {
		UInt32 parseItrtn=0;
		
        #region Fields
        private List<DynamicVariable> vars;
        private Regex parser = new Regex(@"~([^~]{0,127})~");
        // https://ru.wikipedia.org/wiki/%D0%A0%D0%B5%D0%B3%D1%83%D0%BB%D1%8F%D1%80%D0%BD%D1%8B%D0%B5_%D0%B2%D1%8B%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F
        private ASCIIEncoding ascii = new ASCIIEncoding();
        private String projectDir;
        #endregion
        #region Constructor
        public DynamicVariableParser(String path)
        {
                        this.projectDir = path;
                        vars = new List<DynamicVariable>();
        }
        #endregion

        /// <summary>
        /// Parses and indexes a file for dynamic variables
        /// </summary>
        /// <param name="file">The WBFSFileRecord to parse</param>
        /// <returns>An WBFSFileRecord of indexes, or null if no variables were found</returns>
        public WBFSFileRecord Parse(WBFSFileRecord file)
        {
            //return null;
            byte[] idxData = new byte[0];
			UInt32 dynVarCntr=0;


            MatchCollection matches = parser.Matches(ascii.GetString(file.data));
            foreach(Match m in matches)
            {

                int i = GetIndex(m.Value.Replace("~", "")); // .Replace(" ", "")

                Array.Resize(ref idxData, idxData.Length + 8);                
				file.dynVarCntr = ++dynVarCntr;
			
            }
			parseItrtn++;
				
			// Determine if any matches were made
            if (idxData.Length == 0)
                return null;
            else
            {
                // Set up new file record
                WBFSFileRecord idxFile = new WBFSFileRecord();
                idxFile.FileName = "";
                idxFile.fileDate = file.fileDate;
                idxFile.isIndex = true;
                idxFile.data = idxData;
                return idxFile;
            }
        }

        /// <summary>
        /// Writes out if necessary
        /// </summary>
        /// <returns>TRUE if the files were written, FALSE if no changes are needed</returns>
        public bool WriteIndices()
        {
            // Determine if an update is necessary
            bool isChanged = false;
            foreach (DynamicVariable dv in vars)
            {
                if ((dv.WasUsed && dv.Count == 0) ||
                    (!dv.WasUsed && dv.Count != 0))
                {
                    isChanged = true;
                    break;
                }
            }
            if (!isChanged)
                return false;

            // Write out HTTPPrint.idx
            StreamWriter fout = new StreamWriter(projectDir + "web_vars.txt", false);
            foreach (DynamicVariable dv in vars)
            {
                fout.WriteLine(dv.Name);
            }
            fout.Flush();
            fout.Close();
            return true;
        }

        #region Private Methods
        /// <summary>
        /// Finds the index of a dynamic variable, or creates a new one
        /// </summary>
        /// <param name="name"></param>
        /// <returns>The index of the dynamic variable</returns>
        private int GetIndex(String name)
        {
            // Search for the dynamic variable
            DynamicVariable dv = new DynamicVariable(name);
            int i = vars.IndexOf(dv);
            
            // If not found, add a new one
            if (i == -1)
            {
                vars.Add(dv);
                i = vars.Count - 1;
            }

            // Mark as used and return the index
            vars[i].Count++;
            return i;
        }
        #endregion

    }

    public class DynamicVariable
    {
        #region Fields
        private String name;
        private bool wasUsed;
        private int count;
        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets the name of this DynamicVariable
        /// </summary>
        public String Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

       /// <summary>
        /// Indicates if this specific instance was previously used
        /// </summary>
        public bool WasUsed
        {
            get { return this.wasUsed; }
            set { this.wasUsed = value; }
        }

        /// <summary>
        /// Indicates how many times this instance is used
        /// </summary>
        public int Count
        {
            get { return this.count; }
            set { this.count = value; }
        }
        #endregion

        #region Constructor
        public DynamicVariable(String name)
        {
            this.name = name.Trim(); //  Regex.Replace(name, @"[\ \+]", "");
            this.count = 0;
        }
        #endregion
        public override int GetHashCode()
        {
            return this.name.GetHashCode();
        }
    }

}
