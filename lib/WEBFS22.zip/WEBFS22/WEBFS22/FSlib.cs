/*********************************************************************
 *    FS Generator Library
 ********************************************************************/
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.IO;
using System.IO.Compression;
using System.Text.RegularExpressions;

namespace WEBFS
{
	public class FileRecord
    {
 	    #region Fields
        public UInt16 nameHash;
		public UInt32 fileRecordOffset;
		public UInt32 dynVarCntr=0;
		
        #endregion
 
 	   public FileRecord(UInt16 nameHash, UInt32 fileRecordOffset,UInt32 dynVarCntr)
 	   {
 		   this.nameHash = nameHash;
 		   this.fileRecordOffset = fileRecordOffset;
		   this.dynVarCntr = dynVarCntr;
 	   }
    }

    public abstract class WBFSBuilder
    {
        #region Fields
        protected String Mddpath ;
        protected String localPath;
        protected String localFile;
        protected List<string> log;
        protected List<WBFSFileRecord> files;
        protected String generatedImageName;
        protected bool indexUpdated;
        #endregion

        #region Properties
        /// <summary>
        /// Specifies the path for the image file, along with any associated index files
        /// </summary>
        protected String LocalPath
        {
            get { return this.localPath; }
            set { this.localPath = value; }
        }

        /// <summary>
        /// Specifies the name of the image file to save to the file system
        /// </summary>
        protected String LocalFile
        {
            get { return this.localFile; }
            set { this.localFile = value; }
        }

        /// <summary>
        /// Retrieves the file name of the most recently generated image
        /// </summary>
        public String GeneratedImageFileName
        {
            get { return this.generatedImageName; }
        }

        /// <summary>
        /// Retrieves the log from the last procedure
        /// </summary>
        public List<string> Log
        {
            get { return this.log; }
        }

        /// <summary>
        /// Indicates whether or not the index file was updated
        /// </summary>
        public bool IndexUpdated
        {
            get { return this.indexUpdated; }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Creates a new WBFSBuilder
        /// </summary>
        public WBFSBuilder()
        {
            // do nothing
        }
        #endregion
    
        #region Methods
        /// <summary>
        /// Adds a file to the FS image
        /// </summary>
        /// <param name="localName">Local file name to read</param>
        /// <param name="imageName">Name to use in image file</param>
        public abstract bool AddFile(String localName, String imageName);

        /// <summary>
        /// Recursively adds a directory of files to the image
        /// </summary>
        /// <param name="dataPath">Local directory name to add</param>
        /// <param name="imagePath">Path in FS image to add files to</param>
        public abstract bool AddDirectory(String dataPath, String imagePath);

        /// <summary>
        /// Generates the FS image and any necessary support files
        /// </summary>
        public abstract bool Generate();
        #endregion

    }

    public class WBFSClassicBuilder : WBFSBuilder
    {
        #region Fields
        public UInt32 ReserveBlock;
        #endregion

        #region Constructor
        /// <summary>
        /// Creates a new WBFS Classic image builder
        /// </summary>
        /// <param name="localPath">The directory to save the image in</param>
        /// <param name="localFile">The output file name for the image</param>
        public WBFSClassicBuilder(String localPath, String localFile)
        {
            if (!localPath.EndsWith("\\"))
                localPath += "\\";
            this.LocalPath = localPath;
            this.LocalFile = localFile;
            this.ReserveBlock = 0;
            this.log = new List<string>();
            this.files = new List<WBFSFileRecord>();
            this.indexUpdated = false;
        }
        #endregion

        #region Constants
        const byte WBFS_DATA = 0x00;
        const byte WBFS_DELETED = 0x01;
        const byte WBFS_DLE = 0x03;
        const byte WBFS_ETX = 0x04;

        #endregion

        #region Public Methods
        /// <summary>
        /// Adds a file to the FS image
        /// </summary>
        /// <param name="localName">Local file name to read</param>
        /// <param name="imageName">Name to use in image file</param>
        public override bool AddFile(String localName, String imageName)
        {
            // Skip if can't be opened
            if (!File.Exists(localName))
            {
                log.Add("\r\nERROR: Could not read " + localName);
                return false;
            }

            // Set up the new file record
            WBFSFileRecord newFile = new WBFSFileRecord();
            newFile.FileName = imageName;

            // Read the data in, escaping as it is read
            byte b;
            List<byte> data = new List<byte>(1024);
            FileStream fs = new FileStream(localName, FileMode.Open, FileAccess.Read);
            BinaryReader fin = new BinaryReader(fs);
            for (int i = 0; i < fs.Length; i++)
            {
                if(data.Count == data.Capacity)
                    data.Capacity *= 2;

                b = fin.ReadByte();
                if (b == WBFS_DLE || b == WBFS_ETX)
                    data.Add(WBFS_DLE);
                data.Add(b);
            }
            fin.Close();
            newFile.data = data.ToArray();

            // Add the file and return
            log.Add("    " + imageName + ": " + newFile.data.Length + " bytes");
            files.Add(newFile);

            return true;
        }

        /// <summary>
        /// Adds a directory to the FS image.  All non-hidden files will be included.
        /// </summary>
        /// <param name="dataPath">The local directory to search</param>
        /// <param name="imagePath">Ignored for WBFS Classic</param>
        /// <returns></returns>
        public override bool AddDirectory(String dataPath, String imagePath)
        {
            // Make sure directory exists
            if (!Directory.Exists(dataPath))
            {
                log.Add("\r\nERROR: Directory " + dataPath + " does not exist.");
                return false;
            }

            // Make sure directory is not the project directory
            if (this.localPath.Contains(dataPath))
            {
                log.Add("\r\nERROR: The project directory is located in the source " +
                        "directory.  The generator cannot run if the image is to be placed " +
                        "in the source directory.  Please select the base MPLAB project " +
                        "directory before continuing.");
                return false;
            }

            // Load directory members
            DirectoryInfo dir = new DirectoryInfo(dataPath);
            FileInfo[] filelist = dir.GetFiles();

            log.Add(dataPath + " :");

            // Add all sub files
            for (int i = 0; i < filelist.Length; i++)
                if ((filelist[i].Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    this.AddFile(filelist[i].FullName, imagePath + filelist[i].Name);

            return true;
        }

        public override bool Generate()
        {
            // Start with nothing
            generatedImageName = null;

            // Make sure all paths exist
            if (!Directory.Exists(localPath))
            {
                log.Add("\r\nERROR: Output directory \"" + localPath + "\" does not exist!");
                return false;
            }

            // Make sure we have some files
            if(files.Count == 0)
                return false;

            // Generate based on format
            try
            {
                    return GenerateBIN(localPath + localFile);
            }
            catch (Exception e)
            {
                log.Add("\r\nERROR: " + e.Message);
                return false;
            }

        }

        private bool GenerateBIN(String filename)
        {
            // Open the file
            if (!filename.EndsWith(".bin", StringComparison.OrdinalIgnoreCase))
                filename += ".bin";
            BinaryWriter fout = new BinaryWriter(new FileStream(filename, FileMode.Create), Encoding.ASCII);

            // Write the FAT data
            UInt32 baseAddr = ReserveBlock + 17 * ((UInt32)files.Count + 1);
            foreach (WBFSFileRecord file in files)
            {
                fout.Write(WBFS_DATA);
                fout.Write((byte)(baseAddr));
                fout.Write((byte)(baseAddr >> 8));
                fout.Write((byte)(baseAddr >> 16));
                fout.Write((byte)(baseAddr >> 24));
                fout.Write(NormalizeFileName(file.FileName).ToCharArray());
                baseAddr += (UInt32)file.data.Length + 5;
            }
            fout.Write(WBFS_ETX);
            fout.Write((uint)0xffffffff);
            fout.Write("END OF FAT  ".ToCharArray());

            // Write the files
            foreach (WBFSFileRecord file in files)
            {
                fout.Write(file.data);
                fout.Write(WBFS_ETX);
                fout.Write((uint)0xffffffff);
            }

            // Flush the output and store the file name
            fout.Flush();
            fout.Close();
            generatedImageName = filename;
            return true;
        }

        private String NormalizeFileName(String name)
        {
            if (name.Length > 12)
                name = name.Substring(0, 12);
            return name.PadRight(12).ToUpper();
        }

        #endregion
    }

    public class WBFS2Builder : WBFSBuilder
    {
        #region Fields
        private Collection<String> dynamicTypes;
        private Collection<String> nonGZipTypes;
        private DynamicVariableParser dynVarParser;
        #endregion

        #region Constants
        private const UInt16 WBFS2_FLAG_ISZIPPED = 0x0001;
        private const UInt16 WBFS2_FLAG_HASINDEX = 0x0002;
        #endregion

        #region Constructor
        /// <summary>
        /// Creates a new WBFS2 image builder
        /// </summary>
        /// <param name="localPath">The directory to save the image in, and to read/write index files</param>
        /// <param name="localFile">The output file name for the image</param>
        public WBFS2Builder(String localPath, String localFile)
        {
            if (!localPath.EndsWith("\\"))
                localPath += "\\";
            this.LocalPath = localPath;
            this.LocalFile = localFile;
            this.dynamicTypes = new Collection<string>();
            this.nonGZipTypes = new Collection<string>();
            this.log = new List<string>();
            this.files = new List<WBFSFileRecord>();
            this.dynVarParser = new DynamicVariableParser(localPath);
            this.indexUpdated = false;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Sets a comma-separated list of types to be considered dynamic
        /// </summary>
        public string DynamicTypes
        {
            set
            {
                Array strings = value.Split(',');
                dynamicTypes.Clear();
                foreach (String s in strings)
                {
                    String s_trimmed = s.Replace('*', ' ').Trim();
                    if (s_trimmed.Length > 0)
                        this.dynamicTypes.Add(s_trimmed);
                }
            }
        }

        /// <summary>
        /// Sets a comma-separated list of types not to be compressed
        /// </summary>
        public string NonGZipTypes
        {
            set
            {
                Array strings = value.Split(',');
                nonGZipTypes.Clear();
                foreach (String s in strings)
                {
                    String s_trimmed = s.Replace('*',' ').Trim();
                    if (s_trimmed.Length > 0)
                        this.nonGZipTypes.Add(s_trimmed);
                }
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Adds a file to the FS image
        /// </summary>
        /// <param name="localName">Local file name to read</param>
        /// <param name="imageName">Name to use in image file</param>
        public override bool AddFile(String localName, String imageName)
        {
            // Skip if can't be opened
            if (!File.Exists(localName))
            {
                log.Add("\r\nERROR: Could not read " + localName);
                return false;
            }

            // Set up the new file record
            WBFSFileRecord newFile = new WBFSFileRecord();
            newFile.FileName = imageName;
            newFile.fileDate = File.GetLastWriteTime(localName);

            // Read the data in
            FileStream fs = new FileStream(localName, FileMode.Open, FileAccess.Read);
            BinaryReader fin = new BinaryReader(fs);
            newFile.data = fin.ReadBytes((int)fs.Length);
            fin.Close();

            // Parse the file if necessary
            WBFSFileRecord idxFile = null;
            if (this.FileMatches(localName, this.dynamicTypes))
            {
                idxFile = dynVarParser.Parse(newFile);
            }

            // GZip the file if possible
            int gzipRatio = 0;
            if (idxFile == null && !this.FileMatches(localName, this.nonGZipTypes))
            {
                MemoryStream ms = new MemoryStream();
                GZipStream gz = new GZipStream(ms, CompressionMode.Compress, true);
                gz.Write(newFile.data, 0, newFile.data.Length);
                gz.Flush();
                gz.Close();

                // Only use zipped copy if it's smaller
                if (ms.Length < newFile.data.Length)
                {
                    gzipRatio = (int)(100 - (100 * ms.Length / newFile.data.Length));
                    newFile.data = ms.ToArray();
                    newFile.isZipped = true;
                }
            }
            
            // Add the file and return
            if (idxFile == null)
            {
                log.Add("    " + imageName + ": " + newFile.data.Length + " bytes" + 
                    ((gzipRatio > 0) ? " (gzipped by " + gzipRatio + "%)" : ""));
                files.Add(newFile);
            }
            else
            {
                log.Add("    " + imageName + ": " + newFile.data.Length + " bytes, " + (idxFile.data.Length / 8) + " vars");
                newFile.hasIndex = true;
                files.Add(newFile);
            }
            return true;
        }

        /// <summary>
        /// Recursively adds a directory to the FS image.  All non-hidden files will be included.
        /// </summary>
        /// <param name="dataPath">The local directory to search</param>
        /// <param name="imagePath">The base directory this folder is in the WBFS2 image</param>
        /// <returns></returns>
        public override bool AddDirectory(String dataPath, String imagePath)
        {
            // Make sure directory exists
            if (!Directory.Exists(dataPath))
            {
                log.Add("\r\nERROR: Directory " + dataPath + " does not exist.");
                return false;
            }

            // Make sure directory is not the project directory
            if (this.localPath.Contains(dataPath))
            {
                log.Add("\r\nERROR: The bin image directory is located in the source " +
                        "directory.  The generator cannot run if the image is to be placed " +
                        "in the source directory.  Please select the bin image " +
                        "directory before continuing.");
                return false;
            }
            
            // Load directory members
            DirectoryInfo dir = new DirectoryInfo(dataPath);
            FileInfo[] filelist = dir.GetFiles();
            DirectoryInfo[] subdirs = dir.GetDirectories();

            log.Add(dataPath + " :");

            // Add all sub files
            for (int i = 0; i < filelist.Length; i++)
                if ((filelist[i].Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    this.AddFile(filelist[i].FullName, imagePath + filelist[i].Name);

            // Add all subdirectories
            for (int i = 0; i < subdirs.Length; i++)
                if((subdirs[i].Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    this.AddDirectory(subdirs[i].FullName, imagePath + subdirs[i].Name + "/");

            return true;
        }

        /// <summary>
        /// Generates an image in the specified format
        /// </summary>
        /// <returns>true if generation was successful, false otherwise</returns>
        public override bool Generate()
        {
            // Start with nothing as the output name
            generatedImageName = null;

            // Make sure all paths exist
            if (!Directory.Exists(localPath))
            {
                log.Add("\r\nERROR: Output directory \"" + localPath + "\" does not exist!");
                return false;
            }

            // Make sure we have some files
            if (files.Count == 0)
                return false;

            try
            {
                // Write any index files that have changed
                indexUpdated = dynVarParser.WriteIndices();
            }
            catch (Exception e)
            {
                log.Add("ERROR: " + e.Message);
                return false;
            }

            // Determine address of each file and string
            UInt32 numFiles = (UInt32)files.Count;
            UInt32 lenHeader = 12; // "WEBF01nn"
            UInt32 lenHashes = 2 * numFiles;

            UInt32 lenFAT = 4 * numFiles;
            UInt32 baseAddr = lenHeader + lenHashes + lenFAT;
			
            foreach (WBFSFileRecord file in files)
            {
                file.locStr = baseAddr;
                baseAddr += (UInt32)file.FileName.Length + 1 + 8;
                file.locData = baseAddr;
                baseAddr += (UInt32)file.data.Length;
            }
            // Set up the writer
            try
            {
                WBFS2Writer w;
                w = new WBFS2BINWriter(localPath + localFile);
                w.ImgLen = baseAddr;
  			    WriteImage(w);	
            }
            catch (Exception e)
            {
                log.Add("\r\nERROR: " + e.Message);
                return false;
            }

            return true;
        }
        #endregion
		private void WriteImage(WBFS2Writer x)
		{
            WBFS2Writer w;

            w = x;
				// Write the image
            w.Write("FWEB");
            w.Write((byte)0x01);
            w.Write((byte)0x00);
            w.Write((UInt16)files.Count);
            w.Write((UInt32)w.ImgLen);

            foreach (WBFSFileRecord file in files)
            {
                w.Write((UInt16)file.nameHash);
            }
            foreach (WBFSFileRecord file in files)
            {
                w.Write(file.locStr);
            }

			UInt16 flags;
			foreach (WBFSFileRecord file in files)
            {
                w.Write((UInt32)file.data.Length + (UInt32)file.FileName.Length + 9);
                w.Write((UInt16)(file.FileName.Length + 9));
                flags = 0;
                if (file.hasIndex)
                    flags |= WBFS2_FLAG_HASINDEX;
                if (file.isZipped)
                    flags |= WBFS2_FLAG_ISZIPPED;
                w.Write(flags);
                w.Write(file.FileName);
                w.Write((byte)0x00);
                w.Write(file.data);

            }
            while ((w.ImageLength & 0x0000000f) != 0) w.Write((byte)0xFF);  

            w.Close();
            generatedImageName = w.imageName;

            log.Add("\r\nGENERATED WEBFS IMAGE: " + w.ImageLength + " bytes");

		}

		private class FilesRecordWriter : BinaryWriter 
		{
            #region Fields
            protected BinaryWriter fout;
			public int ImageLength = 0;
            #endregion

            public FilesRecordWriter(String DataPath)
            {
				String filename = "FileRcrd.bin";
			
				string newPath = System.IO.Path.Combine(DataPath, filename);

				if (!filename.EndsWith(".bin", StringComparison.OrdinalIgnoreCase))
									filename += ".bin";
								
				fout = new BinaryWriter(new FileStream(newPath, FileMode.Create), Encoding.ASCII);
            }

			public void Write(byte data)
            {
				fout.Write(data);
				ImageLength++;
	        }
			
            public void Close()
            {
                fout.Close();
            }
        }

		private class DynamicVarRecordWriter : BinaryWriter
		{
			#region Fields
			protected BinaryWriter fout;
			#endregion

			public DynamicVarRecordWriter(String DataPath)
			{

				String filename = "DynRcrd.bin";

				//Create a new subfolder under the current active folder
				string newPath = System.IO.Path.Combine(DataPath, filename);
				
				if (!filename.EndsWith(".bin", StringComparison.OrdinalIgnoreCase))
					filename += ".bin";
				fout = new BinaryWriter(new FileStream(newPath, FileMode.Create), Encoding.ASCII);

			}
			//public override void Write(byte data)
            public void Write(byte data)
			{				
				fout.Write(data);
			}

			//public override void Close()
             public void Close()
			 {
				fout.Close();
			 } 
		}
		

        //public bool MDDWriter(String localPath)
        public void MDDWriter(String localPath)
		{
	    	FilesRecordWriter FileRecrd /*Files with dynamic variables Record*/;
	        DynamicVarRecordWriter DynVarRecrd /*Dynamic Variables Record of each file*/;

            UInt32 counter = 0;
            UInt32 loopCntr = 0;
            UInt32 numFileRecrds = 0;
			
	        FileRecrd = new FilesRecordWriter(localPath);
			DynVarRecrd = new DynamicVarRecordWriter(localPath);


			UInt16 flags;
			List<FileRecord> FileRcrdList = new List<FileRecord>();
	        
			foreach (WBFSFileRecord file in files)
	        {
	        	counter=0;
				loopCntr=0;
	        	if(file.dynVarCntr >0)
	        	{
					FileRcrdList.Add(new FileRecord ((UInt16)file.nameHash,
													 (UInt32)file.fileRecordOffset,
													 (UInt32)file.dynVarCntr));
					numFileRecrds++;

		
					DynVarRecrd.Write((byte)(file.fileRecordLength));
					DynVarRecrd.Write((byte)(file.fileRecordLength>>8));
					DynVarRecrd.Write((byte)(file.fileRecordLength>>16));
					DynVarRecrd.Write((byte)(file.fileRecordLength>>24));

					
					flags = 0;
					if (file.hasIndex)
						flags |= WBFS2_FLAG_HASINDEX;
					if (file.isZipped)
						flags |= WBFS2_FLAG_ISZIPPED;


					DynVarRecrd.Write((byte)(flags));
					DynVarRecrd.Write((byte)(flags>>8));

					loopCntr=0;
					
	                while(loopCntr!=file.dynVarCntr)
					{

						DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[0+counter]));
						DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[1+counter]));
						DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[2+counter]));
						DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[3+counter]));

						DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[4 + counter]));
	                    DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[5 + counter]));
	                    DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[6 + counter]));
	                    DynVarRecrd.Write((byte)(file.dynVarOffsetAndIndexID[7 + counter]));


						counter+=8;
						loopCntr+=1;
					}

				}
		        }

	       FileRcrdList.Sort(delegate(FileRecord FR1, FileRecord FR2) 
				{
					return FR1.nameHash.CompareTo(FR2.nameHash); 
				}
			);

			FileRecrd.Write((byte)(numFileRecrds));
	        FileRecrd.Write((byte)(numFileRecrds>>8));
	        FileRecrd.Write((byte)(numFileRecrds>>16));
	        FileRecrd.Write((byte)(numFileRecrds>>24));	

			FileRcrdList.ForEach(delegate(FileRecord FR) 
				{
	                FileRecrd.Write((byte)(FR.nameHash));
					FileRecrd.Write((byte)(FR.nameHash>>8));
	                FileRecrd.Write((byte)(FR.fileRecordOffset));
	                FileRecrd.Write((byte)(FR.fileRecordOffset>>8));
	                FileRecrd.Write((byte)(FR.fileRecordOffset>>16));
	                FileRecrd.Write((byte)(FR.fileRecordOffset>>24));
	                FileRecrd.Write((byte)(FR.dynVarCntr));
	                FileRecrd.Write((byte)(FR.dynVarCntr>>8));
	                FileRecrd.Write((byte)(FR.dynVarCntr>>16));
	                FileRecrd.Write((byte)(FR.dynVarCntr>>24));

				}
			);

	        log.Add("\r\nGENERATED WEBFS IMAGE: " + FileRecrd.ImageLength + " bytes");

			FileRecrd.Close();
			DynVarRecrd.Close();
	     
	    }
        #region Private Methods
        private bool FileMatches(String fileName, Collection<String> endings)
        {
            foreach(String end in endings)
                if(fileName.EndsWith(end))
                    return true;
            return false;
        }
        #endregion

        #region Writer Classes
        private abstract class WBFS2Writer
        {
            public int ImageLength = 0;
            public UInt32 ImgLen = 0;
            public string imageName;

            public abstract void Write(byte data);
            public abstract void Close();

            public void Write(byte[] data)
            {
                foreach (byte b in data)
                    Write(b);
            }

            public void Write(String data)
            {
                foreach (byte b in data)
                    Write(b);
            }

            public void Write(UInt16 data)
            {
                Write((byte)(data));
                Write((byte)(data >> 8));
            }

            public void Write(UInt32 data)
            {
                Write((byte)(data));
                Write((byte)(data >> 8));
                Write((byte)(data >> 16));
                Write((byte)(data >> 24));
            }
        }

        private class WBFS2BINWriter : WBFS2Writer
        {
            #region Fields
            protected BinaryWriter fout;
            #endregion

            public WBFS2BINWriter(String filename)
            {
                if (!filename.EndsWith(".bin", StringComparison.OrdinalIgnoreCase))
                    filename += ".bin";
                fout = new BinaryWriter(new FileStream(filename, FileMode.Create), Encoding.ASCII);
                imageName = filename;
            }

            public override void Write(byte data)
            {
                ImageLength++;
 	            fout.Write(data);
            }

            public override void Close()
            {
                fout.Flush();
                fout.Close();
            }
        }
        #endregion
    }

    public class WBFSFileRecord
    {
        #region Fields
        private String fileName;
        public UInt16 nameHash;
	    public DateTime fileDate;
        public byte[] data;
        public UInt32 locStr;
        public UInt32 locData;
        public bool hasIndex;
        public bool isIndex;
        public bool isZipped;
		public UInt32 dynVarCntr=0;/*Number of Dynamic Variables in the file*/
		public byte[] dynVarOffsetAndIndexID = new byte[0];/*Location of dynamic var and its ID*/
		public UInt32 fileRecordOffset;/* Byte location in the Record file where this file record/information is written from*/
        public UInt32 fileRecordLength;/* Total length/number of bytes in this file record*/
        #endregion

        #region Constructor
        /// <summary>
        /// Sets up a new WBFSFileRecord
        /// </summary>
        public WBFSFileRecord()
        {
            locStr = 0;
            locData = 0;
            hasIndex = false;
            isIndex = false;
            isZipped = false;
			dynVarCntr=0;
        }
        #endregion

        public String FileName
        {
            get { return this.fileName; }
            set 
            {
                this.fileName = value;
                if(value == "")
                    this.nameHash = 0xffff;
                else
                {
                    this.nameHash = 0;
                    foreach (byte b in value)
                    {
                        nameHash += b;
                        nameHash <<= 1;
                    }
                }
            }
        }
    }
}
